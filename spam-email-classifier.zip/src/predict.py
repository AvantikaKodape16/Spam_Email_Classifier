import os
import joblib
from preprocess import clean_text

def load_model(model_path=None, vectorizer_path=None):
    if model_path is None:
        model_path = os.path.join("..", "models", "spam_model.pkl")
    if vectorizer_path is None:
        vectorizer_path = os.path.join("..", "models", "vectorizer.pkl")
    model = joblib.load(model_path)
    vectorizer = joblib.load(vectorizer_path)
    return model, vectorizer

def predict_spam(text, model, vectorizer):
    cleaned = clean_text(text)
    vect = vectorizer.transform([cleaned])
    pred = model.predict(vect)[0]
    return 'Spam' if pred == 1 else 'Ham'

if __name__ == "__main__":
    model, vectorizer = load_model()
    test_email = "Congratulations, you've won a $1000 Walmart gift card. Go to http://bit.ly/123456 to claim now!"
    print("Prediction for test email:", predict_spam(test_email, model, vectorizer))