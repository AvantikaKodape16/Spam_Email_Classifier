import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import joblib
from preprocess import clean_text

def main():
    data_path = os.path.join("..", "data", "spam.csv")
    model_dir = os.path.join("..", "models")
    os.makedirs(model_dir, exist_ok=True)
    model_path = os.path.join(model_dir, "spam_model.pkl")
    vectorizer_path = os.path.join(model_dir, "vectorizer.pkl")

    df = pd.read_csv(data_path, encoding='latin-1')
    df = df[['v1', 'v2']]
    df.columns = ['label', 'text']

    df['clean_text'] = df['text'].apply(clean_text)
    df['label_num'] = df['label'].map({'ham': 0, 'spam': 1})

    X_train, X_test, y_train, y_test = train_test_split(
        df['clean_text'], df['label_num'], test_size=0.2, random_state=42
    )

    vectorizer = TfidfVectorizer()
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

    model = MultinomialNB()
    model.fit(X_train_vec, y_train)

    joblib.dump(model, model_path)
    joblib.dump(vectorizer, vectorizer_path)

    print(f"Training complete. Model saved to {model_path}, vectorizer to {vectorizer_path}")

if __name__ == "__main__":
    main()