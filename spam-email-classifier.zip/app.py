import streamlit as st
from src.predict import load_model, predict_spam

st.title("📧 Spam Email Classifier")

st.write(
    "Enter an email message below to check if it's **Spam** or **Ham** (not spam)."
)

model, vectorizer = load_model()

user_input = st.text_area("Paste your email here:")

if st.button("Classify"):
    if user_input.strip():
        result = predict_spam(user_input, model, vectorizer)
        st.markdown(
            f"### Prediction: {'🚫 **Spam**' if result == 'Spam' else '✅ **Ham**'}"
        )
    else:
        st.warning("Please enter an email message to classify.")